import os
from flask import Flask, render_template, request, jsonify, session
from dotenv import load_dotenv
import requests
import uuid

# Load environment variables from .env file if it exists
load_dotenv('My_Chatbot2.env')

app = Flask(__name__)

# Set a secret key for session management
app.secret_key = os.urandom(24)

# API endpoint for Groq
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
@app.route('/')
def index():
    # Ensure a unique session ID for conversation tracking
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
    return render_template('index.html')

@app.route('/check-api-key')
def check_api_key():
    # Check if GROQ_API_KEY exists in environment variables
    api_key = os.environ.get('GROQ_API_KEY')
    return jsonify({'api_key_exists': bool(api_key)})

@app.route('/ask', methods=['POST'])
def ask_question():
    try:
        # Get the question from the request
        data = request.get_json()
        question = data.get('question', '').strip()
        
        if not question:
            return jsonify({'error': 'No question provided'})
        
        # Get API key
        api_key = os.environ.get('GROQ_API_KEY')
        if not api_key:
            return jsonify({'error': 'API key not configured'})
        
        # Retrieve or initialize conversation history
        if 'conversation_history' not in session:
            session['conversation_history'] = []
        
        # Prepare messages for API request
        messages = [
            {'role': 'system', 'content': 'You are a helpful medical assistant. Provide concise, accurate information about medical conditions and treatments. Maintain context across multiple questions in a conversation.'}
        ]
        
        # Add previous conversation context
        messages.extend(session['conversation_history'])
        
        # Add current user question
        messages.append({'role': 'user', 'content': question})
        
        # Prepare the request to Groq API
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            'model': 'llama3-8b-8192',
            'messages': messages,
            'temperature': 0.7,
            'max_tokens': 500
        }
        
        # Make the request to Groq API
        response = requests.post(GROQ_API_URL, headers=headers, json=payload)
        response.raise_for_status()
        
        # Process the response
        result = response.json()
        answer = result['choices'][0]['message']['content']
        
        # Update conversation history
        session['conversation_history'].append({'role': 'user', 'content': question})
        session['conversation_history'].append({'role': 'assistant', 'content': answer})
        
        # Limit conversation history to last 6 messages to prevent excessive token usage
        session['conversation_history'] = session['conversation_history'][-6:]
        
        # Save the session
        session.modified = True
        
        return jsonify({
            'answer': answer,
            'source': 'Groq LLM API',
            'focus_area': 'Medical Information'
        })
        
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'API request error: {str(e)}'})
    except Exception as e:
        return jsonify({'error': f'An error occurred: {str(e)}'})

@app.route('/reset-conversation', methods=['POST'])
def reset_conversation():
    # Clear the conversation history
    if 'conversation_history' in session:
        del session['conversation_history']
    return jsonify({'status': 'Conversation reset successfully'})

if __name__ == '__main__':
    app.run(debug=True)